# EarthFlood

A zero-cost, browser-deployable research prototype that displays weather-based rainfall indicators for a selected location.

## Important safety and research note

EarthFlood is not an official flood warning service. Rainfall-only indicators are not validated flood predictions and do not measure river levels, drainage capacity, soil saturation, or street-level inundation. Do not use the dashboard for emergency decisions. Follow official local warnings.

## Files

- `app.py` — Streamlit dashboard, Open-Meteo geocoding and forecast calls, transparent demo score, charts, map and CSV export.
- `requirements.txt` — Python dependencies.
- `.gitignore` — ignores common temporary files.

## Run in a browser

1. Create a GitHub repository named `earthflood`.
2. Open its **Code** menu and create a GitHub Codespace, if your account has free usage available.
3. Add these files to the repository.
4. In the Codespaces terminal, run:

   ```bash
   pip install -r requirements.txt
   streamlit run app.py --server.port 8501
   ```

5. When Codespaces offers to open port 8501, open the forwarded preview.

## Deploy free

1. Push the files to GitHub.
2. Sign in at https://share.streamlit.io/
3. Choose **Create app**, select your repository, and set the main file path to `app.py`.
4. Deploy. Availability and limits are governed by the hosting provider.

## Data provider

The application calls Open-Meteo's geocoding and forecast APIs. Review the provider's current terms and attribution requirements:
- https://open-meteo.com/
- https://open-meteo.com/en/docs

## Demo scoring

The score combines previous 24-hour precipitation, next 24-hour forecast precipitation, peak hourly forecast precipitation, and maximum precipitation probability. The weights and bands are illustrative and are not calibrated flood thresholds or probabilities.

## Research validation plan

1. Collect documented historical flood events and non-event periods for the target region.
2. Obtain suitable historical rainfall and, where possible, river-gauge data.
3. Define the event outcome and forecast horizon before modelling.
4. Compare against simple baselines.
5. Use chronological train/validation/test splits.
6. Report precision, recall, false-alarm rate, missed-event rate, calibration and lead time.
7. Document missing data, API availability and model limitations.
