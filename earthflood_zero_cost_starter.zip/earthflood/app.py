import requests
import pandas as pd
import streamlit as st
import plotly.express as px
import folium
from streamlit_folium import st_folium
from datetime import datetime, timezone

st.set_page_config(page_title="EarthFlood | Research Dashboard", page_icon="🌍", layout="wide")

st.title("🌍 EarthFlood")
st.caption("Zero-cost flood-risk research prototype • Live weather data • Not an official warning service")

st.warning(
    "Research prototype only: rainfall-based indicators are NOT a verified flood forecast. "
    "This app does not measure river level, drainage capacity, soil saturation, or street-level inundation. "
    "Do not use it for emergency decisions; follow official local warnings."
)

GEOCODE_URL = "https://geocoding-api.open-meteo.com/v1/search"
FORECAST_URL = "https://api.open-meteo.com/v1/forecast"

@st.cache_data(ttl=1800, show_spinner=False)
def geocode(place: str):
    r = requests.get(GEOCODE_URL, params={
        "name": place, "count": 8, "language": "en", "format": "json"
    }, timeout=15)
    r.raise_for_status()
    return r.json().get("results", [])

@st.cache_data(ttl=900, show_spinner=False)
def get_weather(lat: float, lon: float):
    params = {
        "latitude": lat,
        "longitude": lon,
        "hourly": "precipitation,precipitation_probability,temperature_2m",
        "daily": "precipitation_sum,precipitation_probability_max",
        "past_days": 2,
        "forecast_days": 7,
        "timezone": "auto"
    }
    r = requests.get(FORECAST_URL, params=params, timeout=20)
    r.raise_for_status()
    payload = r.json()
    hourly = payload.get("hourly", {})
    df = pd.DataFrame({
        "time": pd.to_datetime(hourly.get("time", [])),
        "precipitation_mm": hourly.get("precipitation", []),
        "precipitation_probability_pct": hourly.get("precipitation_probability", []),
        "temperature_c": hourly.get("temperature_2m", [])
    })
    df = df.dropna(subset=["time"]).sort_values("time")
    return payload, df

def calculate_indicators(df, timezone_name):
    # Compare naive local forecast timestamps against the current time in the API's timezone.
    now = pd.Timestamp.now(tz=timezone_name).tz_localize(None)
    past = df[df["time"] <= now]
    future = df[df["time"] >= now]
    last24 = past.tail(24)
    next24 = future.head(24)
    observed_24h = float(last24["precipitation_mm"].fillna(0).sum()) if not last24.empty else 0.0
    forecast_24h = float(next24["precipitation_mm"].fillna(0).sum()) if not next24.empty else 0.0
    peak_hour = float(next24["precipitation_mm"].fillna(0).max()) if not next24.empty else 0.0
    peak_probability = float(next24["precipitation_probability_pct"].fillna(0).max()) if not next24.empty else 0.0

    # Transparent demo heuristic only; thresholds are not calibrated flood thresholds.
    score = 0
    score += min(35, observed_24h / 2.0)
    score += min(35, forecast_24h / 2.0)
    score += min(20, peak_hour * 4.0)
    score += min(10, peak_probability / 10.0)
    score = round(min(100, score))

    if score < 20:
        label, guidance = "LOW INDICATOR", "Rainfall indicators are relatively low in this simple model. This does not prove there is no flood risk."
    elif score < 45:
        label, guidance = "WATCH INDICATOR", "Rainfall indicators are elevated. Check official weather and local flood updates."
    elif score < 70:
        label, guidance = "HIGH INDICATOR", "Rainfall indicators are high in this demo model. Verify conditions using official local sources."
    else:
        label, guidance = "VERY HIGH INDICATOR", "The demo model sees strong rainfall indicators. This is not an official alert; consult authorities immediately for current guidance."
    return {
        "observed_24h": observed_24h,
        "forecast_24h": forecast_24h,
        "peak_hour": peak_hour,
        "peak_probability": peak_probability,
        "score": score,
        "label": label,
        "guidance": guidance
    }

with st.sidebar:
    st.header("📍 Location")
    place = st.text_input("Search city or town", value="Chennai, Tamil Nadu")
    search = st.button("Find location", type="primary", use_container_width=True)
    st.caption("Weather grid points may not represent conditions on your street.")
    if "places" not in st.session_state:
        st.session_state.places = []
    if search:
        try:
            st.session_state.places = geocode(place.strip())
            if not st.session_state.places:
                st.error("No matching place found. Try a nearby city or district.")
        except Exception as e:
            st.error(f"Location search failed: {e}")

    chosen = None
    if st.session_state.places:
        options = [
            f"{p.get('name', 'Unknown')}, {p.get('admin1', '')}, {p.get('country', '')}"
            for p in st.session_state.places
        ]
        selected = st.selectbox("Choose a match", options)
        chosen = st.session_state.places[options.index(selected)]
    else:
        # Chennai default is used until user searches for another location.
        chosen = {"name": "Chennai", "admin1": "Tamil Nadu", "country": "India",
                  "latitude": 13.0827, "longitude": 80.2707}
    refresh = st.button("Refresh live data", use_container_width=True)
    if refresh:
        st.cache_data.clear()
        st.rerun()

if chosen:
    lat, lon = float(chosen["latitude"]), float(chosen["longitude"])
    location_label = ", ".join(filter(None, [
        chosen.get("name"), chosen.get("admin1"), chosen.get("country")
    ]))
    st.subheader(f"📌 {location_label}")
    try:
        with st.spinner("Retrieving live weather forecast…"):
            payload, df = get_weather(lat, lon)
        if df.empty:
            st.error("The weather provider returned no hourly records.")
            st.stop()

        metrics = calculate_indicators(df, payload.get('timezone', 'UTC'))
        a, b, c, d = st.columns(4)
        a.metric("Rainfall (previous 24h)", f"{metrics['observed_24h']:.1f} mm")
        b.metric("Forecast rain (next 24h)", f"{metrics['forecast_24h']:.1f} mm")
        c.metric("Peak hourly forecast", f"{metrics['peak_hour']:.1f} mm")
        d.metric("Demo indicator score", f"{metrics['score']}/100")

        if metrics["score"] < 20:
            st.success(f"**{metrics['label']}**")
        elif metrics["score"] < 45:
            st.info(f"**{metrics['label']}**")
        else:
            st.error(f"**{metrics['label']}**")
        st.write(metrics["guidance"])
        st.caption("Score is a transparent, uncalibrated research heuristic—not a probability of flooding.")

        st.markdown("### 🌧️ Hourly rainfall")
        chart_df = df.copy()
        local_now = pd.Timestamp.now(tz=payload.get("timezone", "UTC")).tz_localize(None)
        chart_df["period"] = chart_df["time"].apply(
            lambda t: "Past / observed model data" if t <= local_now else "Forecast"
        )
        fig = px.bar(
            chart_df, x="time", y="precipitation_mm", color="period",
            labels={"time": "Local time", "precipitation_mm": "Precipitation (mm)", "period": "Record type"},
            title="Hourly precipitation from Open-Meteo"
        )
        fig.update_layout(legend_title_text="")
        st.plotly_chart(fig, use_container_width=True)

        st.markdown("### 📅 Daily forecast")
        daily = payload.get("daily", {})
        daily_df = pd.DataFrame({
            "date": pd.to_datetime(daily.get("time", [])),
            "precipitation_sum_mm": daily.get("precipitation_sum", []),
            "max_precipitation_probability_pct": daily.get("precipitation_probability_max", [])
        })
        if not daily_df.empty:
            fig2 = px.bar(daily_df, x="date", y="precipitation_sum_mm",
                          hover_data=["max_precipitation_probability_pct"],
                          labels={"date": "Date", "precipitation_sum_mm": "Total precipitation (mm)"},
                          title="Daily precipitation forecast")
            st.plotly_chart(fig2, use_container_width=True)

        st.markdown("### 🗺️ Selected weather grid location")
        m = folium.Map(location=[lat, lon], zoom_start=10, tiles="OpenStreetMap")
        folium.Marker(
            [lat, lon],
            tooltip=location_label,
            popup=f"{location_label}<br>Rainfall indicator: {metrics['score']}/100",
            icon=folium.Icon(color="blue", icon="info-sign")
        ).add_to(m)
        st_folium(m, use_container_width=True, height=380, returned_objects=[])

        st.markdown("### 🧪 Research data")
        st.write("Provider timezone:", payload.get("timezone", "Not supplied"))
        st.write("Coordinates:", f"{lat:.4f}, {lon:.4f}")
        st.write("Records returned:", len(df))
        st.write("Data attribution: Open-Meteo (forecast models and source details are documented by the provider).")
        st.download_button(
            "Download hourly data as CSV",
            data=df.to_csv(index=False).encode("utf-8"),
            file_name="earthflood_hourly_weather.csv",
            mime="text/csv"
        )
        st.markdown("### 🔬 Next research steps")
        st.markdown(
            "- Compare the rainfall indicator with documented historical flood events.\n"
            "- Add river-gauge observations where a suitable open dataset is available.\n"
            "- Define event labels before training any machine-learning model.\n"
            "- Evaluate false alarms, missed events, precision, recall, and lead time.\n"
            "- Keep a time-based holdout set; do not randomly mix future records into training."
        )
    except requests.exceptions.RequestException as e:
        st.error("Could not reach the weather service. Check the internet connection and try again.")
        st.caption(f"Technical detail: {e}")
    except (KeyError, TypeError, ValueError) as e:
        st.error("The provider returned data in an unexpected format.")
        st.caption(f"Technical detail: {e}")

st.divider()
st.caption("EarthFlood is an educational research prototype. It does not send SMS, contact emergency services, or issue official warnings.")
